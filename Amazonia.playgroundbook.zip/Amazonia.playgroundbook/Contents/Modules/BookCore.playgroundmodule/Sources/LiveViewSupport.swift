//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  Provides supporting functions for setting up a live view.
//

import UIKit
import SwiftUI
import PlaygroundSupport

/// Instantiates a new instance of a live view.
///
//public func instantiateLiveView() -> PlaygroundLiveViewable {
//    let liveViewController = PlaygroundPage.current.setLiveView(IntroductionView())
//    return liveViewController
//}


//public func instantiateLiveView2() -> PlaygroundLiveViewable {
//    var liveViewController: LiveViewController!
//
//        liveViewController = Page2ViewController()
//
//
//    return Page2ViewController()
//}



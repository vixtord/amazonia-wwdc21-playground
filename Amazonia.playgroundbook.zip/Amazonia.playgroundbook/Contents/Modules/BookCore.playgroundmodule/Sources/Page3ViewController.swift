//
//  Page3ViewController.swift
//  BookCore
//
//  Created by Victor S. Duarte on 12/04/21.
//
import SwiftUI
import AVKit
import PlaygroundSupport

public struct PageThree: View {
    
    // Animals States
    @State private var showingSamauma = false
    @State private var showingJaguar = false
    @State private var showingTapir = false
    @State private var showingSpiderMonkey = false
    @State private var showingScarletMacaw = false
    @State var audioPlayer: AVAudioPlayer!
    
    var gatherTheAnimals: Double
    
    // View
    public var body: some View {
        
        ZStack {
            
            // Background
            Image(uiImage: UIImage(named: "bgTrees2.png")!)
                .resizable()
            
            // Samaúma Tree
            Samauma(stateToggle: $showingSamauma)
                .sheet(isPresented: $showingSamauma) {
                    RealSamauma() } .padding(.horizontal, -55)
            
            VStack {
                HStack {
                    
                    // Spider Monkey button
                    SpiderMonkey(stateToggle: $showingSpiderMonkey)
                        .sheet(isPresented: $showingSpiderMonkey) {
                            RealSpiderMonkey() }.padding(50)
                    
                    // Scarlet Macaw button
                    ScarletMacaw(stateToggle: $showingScarletMacaw)
                        .sheet(isPresented: $showingScarletMacaw) {
                            RealScarletMacaw() }.padding(50)
                    
                } // HStack
                
                Spacer()
                
                HStack {
                    
                    // Jaguar button
                    Jaguar(stateToggle: $showingJaguar)
                        .sheet(isPresented: $showingJaguar) {
                            RealJaguar() }
                    
                    Spacer()
                    
                    // Tapir button
                    Tapir(stateToggle: $showingTapir)
                        .sheet(isPresented: $showingTapir) {
                            RealTapir() }.padding(50)
                    
                } // HStack
            } // VStack
            
            // Change the value from (0) to (gatherTheAnimals) to make the animals appear
            .opacity(gatherTheAnimals)
            
            VStack {
                
                Spacer()
                
                // Bush
                Image(uiImage: UIImage(named: "bush.png")!)
                    .resizable()
                    .scaledToFit()
                
            } // VStack
        } // ZStack
        .onAppear {
                        let sound = Bundle.main.path(forResource: "forest", ofType: "mp3")
                        self.audioPlayer = try! AVAudioPlayer(contentsOf: URL(fileURLWithPath: sound!))
                        self.audioPlayer.play()
        }
    } // Body
} // PageThree


// Strcucts meant to be used as the touchable species
struct Samauma: View {
    @Binding var stateToggle: Bool
    
    var body: some View {
        Button(action: {
            self.stateToggle.toggle()
        }, label: {
            Image(uiImage: UIImage(named: "samaumaTree.png")!)
                .resizable()
                .scaledToFill()
                .shadow(radius: 10)
            
        }
        )
    }
}

struct Jaguar: View {
    @Binding var stateToggle: Bool
    @State private var imageWiggles = false
    
    var body: some View {
        Button(action: {
            self.stateToggle.toggle()
        }, label: {
            Image(uiImage: UIImage(named: "jaguar.png")!)
                .resizable()
                .scaledToFit()
                .frame(maxHeight: 400)
                .shadow(radius: 10)
                
        }
        )
    }
}

struct Tapir: View {
    @Binding var stateToggle: Bool
    @State private var imageWiggles = false
    
    var body: some View {
        Button(action: {
            self.stateToggle.toggle()
        }, label: {
            Image(uiImage: UIImage(named: "tapir.png")!)
                .resizable()
                .scaledToFit()
                .frame(maxHeight: 400)
                .shadow(radius: 10)
                
        }
        )
    }
}

struct SpiderMonkey: View {
    @Binding var stateToggle: Bool
    @State private var imageWiggles = false
    
    var body: some View {
        Button(action: {
            self.stateToggle.toggle()
        }, label: {
            Image(uiImage: UIImage(named: "spiderMonkey.png")!)
                .resizable()
                .scaledToFit()
                .frame(maxWidth: 250, maxHeight: 300)
                .shadow(radius: 10)
                .rotationEffect(.degrees(imageWiggles ? -5 : 5))
                .animation(Animation.easeInOut(duration: 2).repeatForever(autoreverses: true))
                .onAppear() {
                    imageWiggles.toggle()
                }
        }
        )
        
    }
}

struct ScarletMacaw: View {
    @Binding var stateToggle: Bool
    @State private var imageWiggles = false

    var body: some View {
        Button(action: {
            self.stateToggle.toggle()
        }, label: {
            Image(uiImage: UIImage(named: "scarletMacaw.png")!)
                .resizable()
                .scaledToFit()
                .frame(maxWidth: 250, maxHeight: 250)
                .shadow(radius: 10)
                .rotationEffect(.degrees(imageWiggles ? -5 : 5))
                .animation(Animation.easeInOut(duration: 3).repeatForever(autoreverses: true))
                .onAppear() {
                    imageWiggles.toggle()
                }
        }
        )
        
    }
}

// Structs meant to contain a real picture of each specie
struct RealSamauma: View {
    var body: some View {
        ZStack {
            Image(uiImage: UIImage(named: "realSamauma.png")!)
                .scaledToFill()
            VStack {
                Spacer()
                
                Text("🌿 This is the Samaúma Tree.")
                    .font(.system(size: 18, weight: .light, design: .rounded))
                    .foregroundColor(Color(#colorLiteral(red: 0.2651175260543823, green: 0.2651681900024414, blue: 0.26511088013648987, alpha: 1.0)))
                    .padding()
                    .background(
                        Capsule()
                            .fill(Color(#colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)))
                            .shadow(radius: 10)
                    )
                    .padding(.bottom, 200)
            }
        }
    }
}

struct RealJaguar: View {
    var body: some View {
        ZStack {
            Image(uiImage: UIImage(named: "realJaguar.png")!)
                .scaledToFill()
            VStack {
                Spacer()
                
                Text("🐆 This is the Jaguar.")
                    .font(.system(size: 18, weight: .light, design: .rounded))
                    .foregroundColor(Color(#colorLiteral(red: 0.2651175260543823, green: 0.2651681900024414, blue: 0.26511088013648987, alpha: 1.0)))
                    .padding()
                    .background(
                        Capsule()
                            .fill(Color(#colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)))
                            .shadow(radius: 10)
                    )
                    .padding(.bottom, 200)
            }
        }
    }
}

struct RealTapir: View {
    var body: some View {
        ZStack {
            Image(uiImage: UIImage(named: "realBrazilianTapir.png")!)
                .scaledToFill()
            VStack {
                Spacer()
                
                Text("🇧🇷 This is the Brazilian Tapir.")
                    .font(.system(size: 18, weight: .light, design: .rounded))
                    .foregroundColor(Color(#colorLiteral(red: 0.2651175260543823, green: 0.2651681900024414, blue: 0.26511088013648987, alpha: 1.0)))
                    .padding()
                    .background(
                        Capsule()
                            .fill(Color(#colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)))
                            .shadow(radius: 10)
                    )
                    .padding(.bottom, 200)
            }
        }
    }
}

struct RealSpiderMonkey: View {
    var body: some View {
        ZStack {
            Image(uiImage: UIImage(named: "realSpiderMonkey.png")!)
                .scaledToFill()
            VStack {
                Spacer()
                
                Text("🐒 This is the Spider Monkey (or Ateles).")
                    .font(.system(size: 18, weight: .light, design: .rounded))
                    .foregroundColor(Color(#colorLiteral(red: 0.2651175260543823, green: 0.2651681900024414, blue: 0.26511088013648987, alpha: 1.0)))
                    .padding()
                    .background(
                        Capsule()
                            .fill(Color(#colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)))
                            .shadow(radius: 10)
                    )
                    .padding(.bottom, 200)
            }
        }
    }
}

struct RealScarletMacaw: View {
    var body: some View {
        ZStack {
            Image(uiImage: UIImage(named: "realScarletMacaw.png")!)
                .scaledToFill()
            VStack {
                Spacer()
                
                Text("🦜 This is the Scarlet Macaw.")
                    .font(.system(size: 18, weight: .light, design: .rounded))
                    .foregroundColor(Color(#colorLiteral(red: 0.2651175260543823, green: 0.2651681900024414, blue: 0.26511088013648987, alpha: 1.0)))
                    .padding()
                    .background(
                        Capsule()
                            .fill(Color(#colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)))
                            .shadow(radius: 10)
                    )
                    .padding(.bottom, 200)
            }
        }
    }
}


public class Page3ViewController: LiveViewController {

    let swiftUiView = UIHostingController(rootView: PageThree(gatherTheAnimals: 0))

    public override func viewDidLoad() {
        super.viewDidLoad()

        addChild(swiftUiView)
        self.view.addSubview(swiftUiView.view)
        setUpConstraints()
    }

    fileprivate func setUpConstraints() {

        swiftUiView.view.translatesAutoresizingMaskIntoConstraints = false
        swiftUiView.view.topAnchor.constraint(equalTo: view.topAnchor).isActive = true
        swiftUiView.view.bottomAnchor.constraint(equalTo: view.bottomAnchor).isActive = true
        swiftUiView.view.leftAnchor.constraint(equalTo: view.leftAnchor).isActive = true
        swiftUiView.view.rightAnchor.constraint(equalTo: view.rightAnchor).isActive = true

    }

    override public func receive(_ message: PlaygroundValue) {
        // Implement this method to receive messages sent from the process running Contents.swift.
        // This method is required by the PlaygroundLiveViewMessageHandler protocol.
        // Use this method to decode any messages sent as PlaygroundValue values and respond accordingly.
        if case let .boolean(opacity) = message {
            if opacity == true {
                swiftUiView.rootView = PageThree(gatherTheAnimals: 1)

            } else {
                return
            }
        }
    }
}

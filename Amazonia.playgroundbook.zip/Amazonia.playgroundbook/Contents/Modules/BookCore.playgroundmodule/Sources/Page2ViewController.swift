//
//  Page2ViewController.swift
//  BookCore
//
//  Created by Victor S. Duarte on 12/04/21.
//

import UIKit
import AVFoundation
import PlaygroundSupport
import Foundation

// Fire
public class Fire {
    let height:Int = 180
    let width:Int = 150
    var xposition:Int = 100
    var yposition:Int = 200
    let nameImageFire:String = "fire.png"

    init(x:Int, y:Int) {
        xposition = x
        yposition = y
    }
}

// Animates fire
public class Animations {
    static public func requireUserAtencion(on onView: UIView) {
        let animation = CABasicAnimation(keyPath: "position")
        animation.duration = 0.07
        animation.repeatCount = 40
        animation.autoreverses = true
        animation.fromValue = NSValue(cgPoint: CGPoint(x: onView.center.x - 5, y: onView.center.y))
        animation.toValue = NSValue(cgPoint: CGPoint(x: onView.center.x + 5, y: onView.center.y))
        onView.layer.add(animation, forKey: "position")
    }
}

// Game UI
public class Page2ViewController : LiveViewController {
    
    // Player
    var audioPlayer = AVAudioPlayer()

    // UI Elements
    var imageViewBackground:UIImageView!
    var imageViewAmazonRiver:UIImageView!
    var lblPoints: UILabel!


    // Game configuration constants
    let maxPointsToWin = 10
    let messageVictory = "Congrats! 🥳 You bravely saved the forest! 🌎"
    let messageLose = "Don't give up, saving the Amazon Rainforest can be hard! Try to not leave the fire for too long next time."
    let imageNameBackground = "bgTrees.png"
    let imageNameAmazonRiver = "amazonRiver.png"

    // Game configutaion variables
    var timeIntervalFireAppears = 1.0
    var timerFireVisible = 2.0
    var currentPoints = 0
    var timerShowFires:Timer!
    var isPlayingGame = true
    var onScreenFires = 0


    override public func viewDidLoad() {
        super.viewDidLoad()

        let view = UIView()
        view.frame = CGRect(x: 0, y: 0, width: self.view.frame.width * 0.5 , height: self.view.frame.height * 0.5)

        imageViewBackground = UIImageView(image: UIImage(named: imageNameBackground))
        imageViewBackground.frame = CGRect(x: 0, y: 0, width: 768, height: 1024)
        imageViewBackground.contentMode = .scaleToFill

        imageViewAmazonRiver = UIImageView(image: UIImage(named: imageNameAmazonRiver))
        imageViewAmazonRiver.frame = CGRect(x: 0, y: self.view.frame.midY * 0.8, width: 768, height: 384)
        imageViewAmazonRiver.contentMode = .scaleToFill

        lblPoints = UILabel(frame: CGRect(x: 15, y: 60, width: 400, height: 100))
        lblPoints.text = "🧯 \(currentPoints.description) / 10"
        lblPoints.font = UIFont.boldSystemFont(ofSize: 40.0)
        lblPoints.textColor = .white
        
        view.addSubview(imageViewBackground)
        self.view.insertSubview(view, at: 0)
        self.view.frame = .zero
        view.addSubview(imageViewAmazonRiver)
        view.addSubview(lblPoints)

        Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(prepareFires), userInfo: nil, repeats: false)
        
        playSound(fileName: "fire", type: "mp3")
    }

    override public func viewDidLayoutSubviews() {
        view.center =  CGPoint(x: view.bounds.width / 2, y: view.bounds.height / 2)
    }

    // Função responsável por iniciar o descremento da contagem para o inicio do jogo.
    @objc public func prepareFires(){
        timerShowFires = Timer.scheduledTimer(timeInterval: timeIntervalFireAppears, target: self, selector: #selector(becomeFireVisible), userInfo: nil, repeats: true)
        becomeFireVisible()
    }


    @objc public func becomeFireVisible(){
        let y = Int.random(in: 300 ..< Int(self.view.frame.height) - 170)
        let x = Int.random(in: 10 ..< Int(self.view.frame.width) - 70)
        let fire = Fire(x: x, y: y)

        let imageView = UIImageView(image: UIImage(named: fire.nameImageFire))

        imageView.frame = CGRect(x: fire.xposition, y: fire.yposition, width: fire.width, height: fire.height)
        Animations.requireUserAtencion(on: imageView)

        let tap = UITapGestureRecognizer(target: self, action: #selector(self.handleTapInFire(_:)))
        imageView.addGestureRecognizer(tap)
        imageView.isUserInteractionEnabled = true

        self.view.addSubview(imageView)
        onScreenFires += 1
        
        if onScreenFires > 3 {
            showFinalMessage(isWinner: false)
        }
        

    }

    //Function responsible for handling when the player touches the fire
    @objc public func handleTapInFire(_ sender: UITapGestureRecognizer) {

        sender.view?.isHidden = true
        sender.view?.removeFromSuperview()
        currentPoints += 1
        onScreenFires -= 1
        lblPoints.text = "🧯 \(currentPoints.description) / 10"

        if (currentPoints == maxPointsToWin){
            showFinalMessage(isWinner: true)
        }
    }

    // Function responsible for making the fire invisible after a while

    // Final message
    public func showFinalMessage(isWinner:Bool){
        isPlayingGame = false
        timerShowFires.invalidate()
        var finalMessageText:String!

        if isWinner {
            // remove all fires
            self.view.subviews.filter{$0.frame.size.width < 160}.forEach {$0.removeFromSuperview()}
            finalMessageText = messageVictory
            audioPlayer.stop()
            playSound(fileName: "forest", type: "mp3")
            lblPoints.text = "🧯 We made it!"
        }
        else{
            finalMessageText = messageLose
            
        }

        let alert = UIAlertController(title: "Result", message: finalMessageText, preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: { _ in
            
            if !isWinner {
                self.gameReboot()
            }
        }))
        self.present(alert, animated: true, completion: nil)

    }
    
    func gameReboot() {
        onScreenFires = 0
        currentPoints = 0
        // remove all fires
        self.view.subviews
            .filter{item in  item.frame.size.width < 160} // todo mundo que é fogo
            .forEach {item in item.removeFromSuperview()} // remove da tela
        prepareFires()
        
    }
    
    // PlaySound
func playSound(fileName: String, type: String, numberOfLoops: Int = 0) {
        if let bundle = Bundle.main.path(forResource: fileName, ofType: type) {
            let backgroundMusic = NSURL(fileURLWithPath: bundle)
            do {
                audioPlayer = try AVAudioPlayer(contentsOf:backgroundMusic as URL)
                audioPlayer.numberOfLoops = numberOfLoops
                audioPlayer.prepareToPlay()
                audioPlayer.play()
            } catch {
                print(error)
            }
        }
    }

}

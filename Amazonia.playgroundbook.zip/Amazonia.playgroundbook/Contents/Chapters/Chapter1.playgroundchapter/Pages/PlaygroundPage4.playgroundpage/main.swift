//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
//#-end-hidden-code
/*:
 ![From here, to the World!](page4cover.png)
 
 I know that the Amazon Rainforest is one of the world's most diverse biomes, but three of our six fellows can't be in the Amazon River, as they are from the Atlantic Ocean, where the river ends.
 
 * Callout(Tip):
 Tap the three animals from the Atlantic Ocean to make them go to their home.
  
 If you discovered which of the three animals were from the Atlantic Ocean, congratulations! You saved the day! 🥳 I hope this Playground inspired you to help the planet even more!
 
 😄 **Don't forget to read about the author**.
 
 
 ### Credits:
 
 All images are permitted to be used in this project.
 Royalty-free music from [Zapsplat](https://www.zapsplat.com)
 
 * ["Dois pirarucus no rio", by Ginkgo100 on Wikipedia](https://pt.wikipedia.org/wiki/Pirarucu#/media/Ficheiro:Arapaima049.JPG)
 * [Blue and Yellow Macaw, by Charles Brongniart on Unsplash](https://unsplash.com/photos/a53e2Zwz7xY)
 * ["Onça-pintada fêmea na região do rio Piqueri, no Pantanal, no Brasil.", by Charles J. Sharp on Wikipedia](https://pt.wikipedia.org/wiki/Panthera_onca#/media/Ficheiro:Jaguar_(Panthera_onca_palustris)_female_Piquiri_River_2.JPG)
 * ["Pink Dolphin", by chem7 on Flickr](https://www.flickr.com/photos/88087720@N00/3047314933/)
 * ["Scarlet Macaw", by Jaime Dantas on Unsplash](https://unsplash.com/photos/djeApmC4Aco)
 * ["Uma ariranha selvagem no Parque Estadual do Cantão", by www.Araguaia.org on Wikipedia](https://pt.wikipedia.org/wiki/Ariranha#/media/Ficheiro:Giant_Otter_Anjo.JPG)
 * ["Spider monkey with long arms ( Ateles fusciceps )", by Petruss on Wikipedia](https://pt.wikipedia.org/wiki/Ateles#/media/Ficheiro:Ateles_fusciceps_Colombia.JPG)
 * ["A majestic giant Samauma tree (Ceiba pentandra) and its roots in the Amazon rainforest.", by Imago Photo on Adobe Stock](https://stock.adobe.com/br/images/a-majestic-giant-samauma-tree-ceiba-pentandra-and-its-roots-in-the-amazon-rainforest-mafumeira-sumauma-or-kapok-concept-of-botany-ecology-environment-conservation-and-biodiversity/299611092?prev_url=detail)
 * ["King Penguin", by Andrew Shiva on Wikipedia](https://shorturl.at/jxyzD)
 * ["Green Sea Turtle", by Brocken Inaglory on Wikipedia](https://en.wikipedia.org/wiki/Green_sea_turtle#/media/File:Green_turtle_swimming_over_coral_reefs_in_Kona.jpg)
 * ["Hippocampus hippocampus", by © Hans Hillewaert on Wikipedia](https://pt.wikipedia.org/wiki/Hippocampus_hippocampus#/media/Ficheiro:Hippocampus_hippocampus_(on_Ascophyllum_nodosum).jpg)
 
 */

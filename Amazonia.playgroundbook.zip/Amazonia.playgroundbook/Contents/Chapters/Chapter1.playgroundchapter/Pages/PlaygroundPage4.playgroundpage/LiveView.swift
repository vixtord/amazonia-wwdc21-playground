//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  Instantiates a live view and passes it to the PlaygroundSupport framework.
//

// Instantiate a new instance of the live view from BookCore and pass it to PlaygroundSupport.

import SwiftUI
import AVKit
import BookCore
import PlaygroundSupport

public struct PageFour: View {
    
    // Animals States
    @State private var showingGiantOtter = false
    @State private var showingPirarucu = false
    @State private var showingPinkDolphin = false
    @State private var showingKingPenguin = false
    @State private var showingSeaTurtle = false
    @State private var showingSeaHorse = false
    @State private var showingAboutTheAuthor = false
    @State var audioPlayer: AVAudioPlayer!
    
    // View
    public var body: some View {
        
        ZStack {
            // Background
            Image(uiImage: UIImage(named: "bgRiver2.png")!)
                .resizable()
                .scaledToFill()
                .imageScale(.small)
            
            VStack {
                Spacer()
            HStack {
                Spacer()
                Image(uiImage: UIImage(named: "byMacawWater.png")!)
                    .padding(.bottom, -150)
                    .padding(.trailing, -70)
            }
            }
            
            VStack {
                HStack {
                    // Giant Otter
                    GiantOtter(stateToggle: $showingGiantOtter)
                        .sheet(isPresented: $showingGiantOtter) {
                            RealGiantOtter()} .padding()
                    
                    VStack {
                        // SeaTurtle
                        SeaTurtle(showing: true, stateToggle: $showingSeaTurtle)
                            .sheet(isPresented: $showingSeaTurtle) {
                                RealSeaTurtle()} .padding()
                    
                        
                        // LionFish
                        KingPenguin(showing: true, stateToggle: $showingKingPenguin)
                            .sheet(isPresented: $showingKingPenguin) {
                                RealKingPenguin()} .padding()
                    } // VStack
                } // HStack
                
                HStack {
                    
                    //SeaHorse
                    SeaHorse(showing: true, stateToggle: $showingSeaHorse)
                        .sheet(isPresented: $showingSeaHorse) {
                            RealSeaHorse()} .padding()
                    
                    //Pirarucu
                    Pirarucu(stateToggle: $showingPirarucu)
                        .sheet(isPresented: $showingPirarucu) {
                            RealPirarucu()} .padding()
                } // HStack
                
                //PinkDolphin
                PinkDolphin(stateToggle: $showingPinkDolphin)
                    .sheet(isPresented: $showingPinkDolphin) {
                        RealPinkDolphin()} .padding()
                
                // Colocar o "Sobre o Autor"
                AboutTheAuthor(stateToggle: $showingAboutTheAuthor)
                    .sheet(isPresented: $showingAboutTheAuthor) {
                        LastView()} .padding(32)
            } // VStack
        }// ZStack
        .onAppear {
                        let sound = Bundle.main.path(forResource: "river", ofType: "mp3")
                        self.audioPlayer = try! AVAudioPlayer(contentsOf: URL(fileURLWithPath: sound!))
                        self.audioPlayer.play()
        }
    } // Body
} // PageFour

// About the Author
struct AboutTheAuthor: View {
    @Binding var stateToggle: Bool
    
    var body: some View {
        Button(action: {
            self.stateToggle.toggle()
        }, label: {
            Text("About the Author")
                .font(.system(size: 22, weight: .semibold, design: .rounded))
                .foregroundColor(Color(#colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)))
                .padding()
                .background(
                    Capsule()
                        .fill(Color(#colorLiteral(red: 1.0, green: 0.4171271324, blue: 0.0002565760224, alpha: 1.0)))
                        .overlay(
                            Capsule()
                                .stroke(Color(#colorLiteral(red: 0.9989764094, green: 0.8946433663, blue: 0.6594769359, alpha: 1.0)), lineWidth: 5))
                )
                .shadow(radius: 10)
        }
        )
        
    }
}


// Species from the Amazon river
struct GiantOtter: View {
    @Binding var stateToggle: Bool
    @State private var imageWiggles = false
    
    var body: some View {
        
        Button(action: {
            self.stateToggle.toggle()
        }, label: {
            Image(uiImage: UIImage(named: "giantOtter.png")!)
                .resizable()
                .scaledToFit()
                .frame(maxWidth: 400)
                .shadow(radius: 10)
                .rotationEffect(.degrees(imageWiggles ? 1 : -1))
                .animation(Animation.easeInOut(duration: 2).repeatForever(autoreverses: true))
                .onAppear() {
                    imageWiggles.toggle()
                }
        }
        )
    }
}

struct PinkDolphin: View {
    @Binding var stateToggle: Bool
    @State private var imageWiggles = false
    
    var body: some View {
        Button(action: {
            self.stateToggle.toggle()
        }, label: {
            Image(uiImage: UIImage(named: "pinkDolphin.png")!)
                .resizable()
                .scaledToFit()
                .frame(maxWidth: 600)
                .shadow(radius: 10)
                .rotationEffect(.degrees(imageWiggles ? -2 : 2))
                .animation(Animation.easeInOut(duration: 2).repeatForever(autoreverses: true))
                .onAppear() {
                    imageWiggles.toggle()
                }
        }
        )
        
    }
}

struct Pirarucu: View {
    @Binding var stateToggle: Bool
    @State private var imageWiggles = false
    
    var body: some View {
        Button(action: {
            self.stateToggle.toggle()
        }, label: {
            Image(uiImage: UIImage(named: "pirarucu.png")!)
                .resizable()
                .scaledToFit()
                .frame(maxWidth: 500)
                .shadow(radius: 10)
                .rotationEffect(.degrees(imageWiggles ? 0 : 2))
                .animation(Animation.easeInOut(duration: 1).repeatForever(autoreverses: true))
                .onAppear() {
                    imageWiggles.toggle()
                }
        }
        )
        
    }
}

//Species from the Atlantic Ocean
struct SeaTurtle: View {
    @State var showing: Bool = true
    @State private var imageWiggles = false
    @Binding var stateToggle: Bool
    
    var body: some View {
        Button(action: {
            self.showing.toggle()
            self.stateToggle.toggle()
        }, label: {
            if showing {
                Image(uiImage: UIImage(named: "seaturtle.png")!)
                    .resizable()
                    .scaledToFit()
                    .frame(maxWidth: 200)
                    .shadow(radius: 10)
                    .animation(Animation.easeInOut(duration: 4).repeatForever(autoreverses: true))
                    .onAppear() {
                        imageWiggles.toggle()
                    }
            } else {
                // WW
                Image(uiImage: UIImage(named: "ww.png")!)
                    .resizable()
                    .scaledToFit()
                    .frame(maxWidth: 200)
                    .shadow(radius: 4)
                    .animation(Animation.easeInOut(duration: 4).repeatForever(autoreverses: true))
                    
            }
            
        }
        )
    }
}

struct KingPenguin: View {
    @State var showing: Bool = true
    @State private var imageWiggles = false
    @Binding var stateToggle: Bool
    
    var body: some View {
        Button(action: {
            self.showing.toggle()
            self.stateToggle.toggle()
        }, label: {
            if showing {
                Image(uiImage: UIImage(named: "kingPenguin.png")!)
                    .resizable()
                    .scaledToFit()
                    .frame(maxWidth: 150)
                    .shadow(radius: 10)
                    .rotationEffect(.degrees(imageWiggles ? -1 : 1))
                    .animation(Animation.easeInOut(duration: 1.5).repeatForever(autoreverses: true))
                    .onAppear() {
                        imageWiggles.toggle()
                    }
            } else {
                // DC
                Image(uiImage: UIImage(named: "dc.png")!)
                    .resizable()
                    .scaledToFit()
                    .frame(maxWidth: 150)
                    .shadow(radius: 4)
                    .rotationEffect(.degrees(imageWiggles ? -1 : 1))
                    .animation(Animation.easeInOut(duration: 1.5).repeatForever(autoreverses: true))
                    
            }
            
        }
        )
    }
}

struct SeaHorse: View {
    @State var showing: Bool = true
    @State private var imageWiggles = false
    @Binding var stateToggle: Bool
    
    var body: some View {
        Button(action: {
            self.showing.toggle()
            self.stateToggle.toggle()
        }, label: {
            if showing {
                Image(uiImage: UIImage(named: "seahorse.png")!)
                    .resizable()
                    .scaledToFit()
                    .frame(maxWidth: 100)
                    .shadow(radius: 10)
                    .animation(Animation.easeInOut(duration: 4).repeatForever(autoreverses: true))
                    .onAppear() {
                        imageWiggles.toggle()
                    }
            } else {
                // 21
                Image(uiImage: UIImage(named: "21.png")!)
                    .resizable()
                    .scaledToFit()
                    .frame(maxWidth: 100)
                    .shadow(radius: 4)
                    .animation(Animation.easeInOut(duration: 4).repeatForever(autoreverses: true))
                    
            }
            
        }
        )
    }
}


// Structs meant to contain a real picture of each specie from the Amazon river
struct RealPinkDolphin: View {
    var body: some View {
        ZStack {
            Image(uiImage: UIImage(named: "realPinkDolphin.png")!)
                .scaledToFill()
            VStack {
                Spacer()
                
                Text("🐬 This is the Pink Dolphin.")
                    .font(.system(size: 18, weight: .light, design: .rounded))
                    .foregroundColor(Color(#colorLiteral(red: 0.2651175260543823, green: 0.2651681900024414, blue: 0.26511088013648987, alpha: 1.0)))
                    .padding()
                    .background(
                        Capsule()
                            .fill(Color(#colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)))
                            .shadow(radius: 10)
                    )
                    .padding(.bottom, 200)
            }
        }
    }
}

struct RealPirarucu: View {
    var body: some View {
        ZStack {
            Image(uiImage: UIImage(named: "realPirarucu.png")!)
                .scaledToFill()
            VStack {
                Spacer()

                Text("🐟 This is the Pirarucu.")
                    .font(.system(size: 18, weight: .light, design: .rounded))
                    .foregroundColor(Color(#colorLiteral(red: 0.2651175260543823, green: 0.2651681900024414, blue: 0.26511088013648987, alpha: 1.0)))
                    .padding()
                    .background(
                        Capsule()
                            .fill(Color(#colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)))
                            .shadow(radius: 10)
                    )
                    .padding(.bottom, 200)
            }
        }
    }
}

struct RealGiantOtter: View {
    var body: some View {
        ZStack {
            Image(uiImage: UIImage(named: "realGiantOtter.png")!)
                .scaledToFill()
            VStack {
                Spacer()
                
                Text("🦦 This is the Giant Otter.")
                    .font(.system(size: 18, weight: .light, design: .rounded))
                    .foregroundColor(Color(#colorLiteral(red: 0.2651175260543823, green: 0.2651681900024414, blue: 0.26511088013648987, alpha: 1.0)))
                    .padding()
                    .background(
                        Capsule()
                            .fill(Color(#colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)))
                            .shadow(radius: 10)
                    )
                    .padding(.bottom, 200)
            }
        }
    }
}

struct RealSeaTurtle: View {
    var body: some View {
        ZStack {
            Image(uiImage: UIImage(named: "realGreenSeaTurtle.png")!)
                .scaledToFill()
            VStack {
                Spacer()
                
                Text("✅ Right! This is the Green Sea Turtle.")
                    .font(.system(size: 18, weight: .light, design: .rounded))
                    .foregroundColor(Color(#colorLiteral(red: 0.2651175260543823, green: 0.2651681900024414, blue: 0.26511088013648987, alpha: 1.0)))
                    .padding()
                    .background(
                        Capsule()
                            .fill(Color(#colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)))
                            .shadow(radius: 10)
                    )
                    .padding(.bottom, 200)
            }
        }
    }
}

struct RealSeaHorse: View {
    var body: some View {
        ZStack {
            Image(uiImage: UIImage(named: "realSeahorse.png")!)
                .scaledToFill()
            VStack {
                Spacer()
                
                Text("✅ Right! This is the Sea Horse.")
                    .font(.system(size: 18, weight: .light, design: .rounded))
                    .foregroundColor(Color(#colorLiteral(red: 0.2651175260543823, green: 0.2651681900024414, blue: 0.26511088013648987, alpha: 1.0)))
                    .padding()
                    .background(
                        Capsule()
                            .fill(Color(#colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)))
                            .shadow(radius: 10)
                    )
                    .padding(.bottom, 200)
            }
        }
    }
}

struct RealKingPenguin: View {
    var body: some View {
        ZStack {
            Image(uiImage: UIImage(named: "realKingPenguin.png")!)
                .scaledToFill()
            VStack {
                Spacer()
                
                Text("✅ Right! This is the King Penguin.")
                    .font(.system(size: 18, weight: .light, design: .rounded))
                    .foregroundColor(Color(#colorLiteral(red: 0.2651175260543823, green: 0.2651681900024414, blue: 0.26511088013648987, alpha: 1.0)))
                    .padding()
                    .background(
                        Capsule()
                            .fill(Color(#colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)))
                            .shadow(radius: 10)
                    )
                    .padding(.bottom, 200)
            }
        }
    }
}

struct LastView: View {
    var body: some View {
        ZStack {
            Rectangle()
                .foregroundColor(Color(#colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)))
            
            VStack {
                Text("Congratulations! 🥳")
                    .font(.system(size: 20, weight: .bold, design: .rounded))
                    .foregroundColor(Color(#colorLiteral(red: 0.2651175260543823, green: 0.2651681900024414, blue: 0.26511088013648987, alpha: 1.0)))
                    .padding(.top)
                
                Text("🌿 In this experience, we’ve learned some wild stuff about the Amazon region. This is also a message to raise the consciousness of the need to always keep developing empathy with the most various beings and helping our planet and I hope you loved it! 🌎")
                    .font(.system(size: 18, weight: .regular, design: .rounded))
                    .baselineOffset(5)
                    .foregroundColor(Color(#colorLiteral(red: 0.2651175260543823, green: 0.2651681900024414, blue: 0.26511088013648987, alpha: 1.0)))
                    .padding()
                
                Divider()
                    .padding(.horizontal)
                    .foregroundColor(Color(#colorLiteral(red: 0.2651175260543823, green: 0.2651681900024414, blue: 0.26511088013648987, alpha: 1.0)))
                
                Text("About the Author")
                    .font(.system(size: 20, weight: .bold, design: .rounded))
                    .foregroundColor(Color(#colorLiteral(red: 0.2651175260543823, green: 0.2651681900024414, blue: 0.26511088013648987, alpha: 1.0)))
                    .padding(.top)
                
                Image(uiImage: UIImage(named: "authorPicture.png")!)
                    .padding()
                
                Text("Victor Duarte is a curious Brazilian developer 🇧🇷, passionate about diversity and creating great experiences for the world. 🌎 Born in Rio de Janeiro, he is currently studying Industrial Design and is part of the Apple Developer Academy Rio team. 🥳")
                    .font(.system(size: 18, weight: .regular, design: .rounded))
                    .baselineOffset(5)
                    .foregroundColor(Color(#colorLiteral(red: 0.2651175260543823, green: 0.2651681900024414, blue: 0.26511088013648987, alpha: 1.0)))
                    .padding()
                
            }
            .foregroundColor(.white)
        }
    }
}

PlaygroundPage.current.setLiveView(PageFour())

//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  Instantiates a live view and passes it to the PlaygroundSupport framework.
//

//
//  Page1ViewController.swift
//  BookCore
//
//  Created by Victor S. Duarte on 12/04/21.
//
import SwiftUI
import AVKit
import BookCore
import PlaygroundSupport



public struct IntroductionView1: View {
    @State private var showingSheet = false
    @State var audioPlayer: AVAudioPlayer!
    
    public var body: some View {
        
        ZStack {
            
            // Background
            Image(uiImage: UIImage(named: "bgTrees2.png")!)
                .resizable()
                .scaledToFill()
                .imageScale(.large)
            
            
            VStack {
                Spacer()
                // Arara
                ShowPicture1(stateToggle: $showingSheet)
                    .sheet(isPresented: $showingSheet) {
                        RealMacaw1()
                    }
            } // VStack
            
            VStack {
                Text("Hi, my name is Arara-Canindé! Lately, I've seen some fires in the forest. Let's go to the next page, so I'll fly up high with you so we can stop the fires as soon as possible! ARARA ARARA!")
                    .font(.system(size: 20, weight: .regular, design: .rounded))
                    .foregroundColor(Color(#colorLiteral(red: 0.26514732837677, green: 0.26514732837677, blue: 0.26514732837677, alpha: 1.0)))
                    .baselineOffset(5)
                    .padding(32)
                    .background(
                        RoundedRectangle(cornerRadius: 25)
                            .foregroundColor(.white)
                    )
                    .padding(32)
                    .padding(.top, 100)
                    .shadow(radius: 10)
                
                
                Spacer()
                
                Text("You can touch the subjects to see a real picture.")
                    .font(.system(size: 18, weight: .light, design: .rounded))
                    .foregroundColor(Color(#colorLiteral(red: 0.26514732837677, green: 0.26514732837677, blue: 0.26514732837677, alpha: 1.0)))
                    .padding()
                    .background(
                        RoundedRectangle(cornerRadius: 25)
                            .foregroundColor(Color(#colorLiteral(red: 0.9989764094, green: 0.8946433663, blue: 0.6594769359, alpha: 1.0)))
                    )
                    .padding(32)
                    .padding(.bottom, 50)
                    .shadow(radius: 10)
            } // VStack
        } // ZStack
        .onAppear {
            let sound = Bundle.main.path(forResource: "forest", ofType: "mp3")
            self.audioPlayer = try! AVAudioPlayer(contentsOf: URL(fileURLWithPath: sound!))
            self.audioPlayer.play()
        }
    } // Body
} // View

// Turns image into a button that opens a sheet view
struct ShowPicture1: View {
    @Binding var stateToggle: Bool
    
    var body: some View {
        Button(action: {
            self.stateToggle.toggle()
        }, label: {
            MacawButton1()
        }
        )
        .padding(.horizontal, 50)
        .padding(.top, 300)
    }
}

// Strcuct meant to be used as an image button
struct MacawButton1: View {
    @State private var imageWiggles = false
    
    var body: some View {
        VStack {
            Image(uiImage: UIImage(named: "byMacaw.png")!)
                .resizable()
                .scaledToFit()
                .shadow(radius: 10)
                .rotationEffect(.degrees(imageWiggles ? 3 : -3))
                .animation(Animation.easeInOut(duration: 2).repeatForever(autoreverses: true))
                .onAppear() {
                    imageWiggles.toggle()
                }
        }
    }
}

// Struct meant to contain a real picture of the subject
struct RealMacaw1: View {
    var body: some View {
        ZStack {
            Image(uiImage: UIImage(named: "realBlueAndYellowMacaw.png")!)
                .scaledToFill()
            VStack {
                Spacer()
                Text("🦜 This is a Blue and Yellow Macaw.")
                    .font(.system(size: 18, weight: .light, design: .rounded))
                    .foregroundColor(Color(#colorLiteral(red: 0.2651175260543823, green: 0.2651681900024414, blue: 0.26511088013648987, alpha: 1.0)))
                    .padding()
                    .background(
                        Capsule()
                            .fill(Color(#colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)))
                            .shadow(radius: 10)
                    )
                    .padding(.bottom, 200)
            }
        }
    }
}


PlaygroundPage.current.setLiveView(IntroductionView1())

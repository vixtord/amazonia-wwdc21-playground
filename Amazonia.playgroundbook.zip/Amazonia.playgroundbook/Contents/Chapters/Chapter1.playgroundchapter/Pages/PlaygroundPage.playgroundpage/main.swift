//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
//#-end-hidden-code
/*:
 ![Why the Amazon Rainforest?](page1cover.png)
 
 Brazil is a country with some very distinctive biomes, each one with its magical beings and characteristics. I live in Rio de Janeiro, a region entirely covered by the Atlantic Forests. As much as I love the [Atlantic Forests](glossary://atlanticForests), today I'm here to talk about the Amazon Rainforest, alternatively, Amazonia, which in the last year suffered from increasing deforestation.
 
 * Callout(FYI):
 You can touch the subjects with the Macaw's appearance to see a real picture and the name of the species. Swipe down the picture area to go back.
 
 Go to the [next page](@next) to learn more about Amazon's Rainforest situation in 2020.

 */

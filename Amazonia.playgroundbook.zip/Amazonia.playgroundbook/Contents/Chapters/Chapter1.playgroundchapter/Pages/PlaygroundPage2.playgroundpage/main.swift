//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
//#-end-hidden-code
/*:
 ![The Amazon Rainforest in 2020](page2cover.png)
 
 In 2020, unfortunately, the Amazon rainforest suffered from increasing deforestation in its area located in Brazil, which:
 
 * Was **182%** higher than the established target of 3,925 km2
 * Represents a reduction of only **44%** instead of the 80% established in law
 * Equates to **648 TgCO2** (or 648 million tons of CO2) emitted to the atmosphere related to gross deforestation
 
 In addition to compromising the greenhouse gas reduction targets, the rise in deforestation has intensified **fires**.
 
 Here we can see the Amazon Rainforest and the [Amazon River](glossary://amazonRiver) from a bird's eye view, so it's easier to see the fires. Let's end the fires in the forest as soon as possible!
 
 * Callout(Tip):
 You can extinguish the fires by tapping on them. Try tapping as soon as possible.
 
 After that, let's go to the [next page](@next) to go down to the forest and get in touch with our fellow animals.
 
 */

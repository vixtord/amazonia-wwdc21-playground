//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  Instantiates a live view and passes it to the PlaygroundSupport framework.
//

// Instantiate a new instance of the live view from BookCore and pass it to PlaygroundSupport.

//import SwiftUI
//import AVKit
//import BookCore
//import PlaygroundSupport
//
//public struct PageThree: View {
//
//    // Animals States
//    @State private var showingSamauma = false
//    @State private var showingJaguar = false
//    @State private var showingTapir = false
//    @State private var showingSpiderMonkey = false
//    @State private var showingScarletMacaw = false
//    @State var audioPlayer: AVAudioPlayer!
//
//    var gatherTheAnimals: Double = 1
//
//    // View
//    public var body: some View {
//
//        ZStack {
//
//            // Background
//            Image(uiImage: UIImage(named: "bgTrees.png")!)
//                .resizable()
//
//            // Samaúma Tree
//            Samauma(stateToggle: $showingSamauma)
//                .sheet(isPresented: $showingSamauma) {
//                    RealSamauma() }
//
//            VStack {
//                HStack {
//
//                    // Spider Monkey button
//                    SpiderMonkey(stateToggle: $showingSpiderMonkey)
//                        .sheet(isPresented: $showingSpiderMonkey) {
//                            RealSpiderMonkey() }.padding(50)
//
//                    // Scarlet Macaw button
//                    ScarletMacaw(stateToggle: $showingScarletMacaw)
//                        .sheet(isPresented: $showingScarletMacaw) {
//                            RealScarletMacaw() }.padding(50)
//
//                } // HStack
//
//                Spacer()
//
//                HStack {
//
//                    // Jaguar button
//                    Jaguar(stateToggle: $showingJaguar)
//                        .sheet(isPresented: $showingJaguar) {
//                            RealJaguar() }
//
//                    Spacer()
//
//                    // Tapir button
//                    Tapir(stateToggle: $showingTapir)
//                        .sheet(isPresented: $showingTapir) {
//                            RealTapir() }.padding(50)
//
//                } // HStack
//            } // VStack
//
//            // Change the value from (0) to (gatherTheAnimals) to make the animals appear
//            .opacity(gatherTheAnimals)
//
//            VStack {
//
//                Spacer()
//
//                // Bush
//                Image(uiImage: UIImage(named: "bush.png")!)
//                    .resizable()
//                    .scaledToFit()
//
//            } // VStack
//        } // ZStack
//        .onAppear {
//                        let sound = Bundle.main.path(forResource: "forest", ofType: "mp3")
//                        self.audioPlayer = try! AVAudioPlayer(contentsOf: URL(fileURLWithPath: sound!))
//                        self.audioPlayer.play()
//        }
//    } // Body
//} // PageThree
//
//
//// Strcucts meant to be used as the touchable species
//struct Samauma: View {
//    @Binding var stateToggle: Bool
//
//    var body: some View {
//        Button(action: {
//            self.stateToggle.toggle()
//        }, label: {
//            Image(uiImage: UIImage(named: "samaumaTree.png")!)
//                .resizable()
//                .scaledToFit()
//                .shadow(radius: 10)
//
//        }
//        )
//    }
//}
//
//struct Jaguar: View {
//    @Binding var stateToggle: Bool
//    @State private var imageWiggles = false
//
//    var body: some View {
//        Button(action: {
//            self.stateToggle.toggle()
//        }, label: {
//            Image(uiImage: UIImage(named: "jaguar.png")!)
//                .resizable()
//                .scaledToFit()
//                .frame(maxHeight: 400)
//                .shadow(radius: 10)
//
//        }
//        )
//    }
//}
//
//struct Tapir: View {
//    @Binding var stateToggle: Bool
//    @State private var imageWiggles = false
//
//    var body: some View {
//        Button(action: {
//            self.stateToggle.toggle()
//        }, label: {
//            Image(uiImage: UIImage(named: "tapir.png")!)
//                .resizable()
//                .scaledToFit()
//                .frame(maxHeight: 400)
//                .shadow(radius: 10)
//
//        }
//        )
//    }
//}
//
//struct SpiderMonkey: View {
//    @Binding var stateToggle: Bool
//    @State private var imageWiggles = false
//
//    var body: some View {
//        Button(action: {
//            self.stateToggle.toggle()
//        }, label: {
//            Image(uiImage: UIImage(named: "spiderMonkey.png")!)
//                .resizable()
//                .scaledToFit()
//                .frame(maxWidth: 250, maxHeight: 300)
//                .shadow(radius: 10)
//                .rotationEffect(.degrees(imageWiggles ? -5 : 5))
//                .animation(Animation.easeInOut(duration: 2).repeatForever(autoreverses: true))
//                .onAppear() {
//                    imageWiggles.toggle()
//                }
//        }
//        )
//
//    }
//}
//
//struct ScarletMacaw: View {
//    @Binding var stateToggle: Bool
//    @State private var imageWiggles = false
//
//    var body: some View {
//        Button(action: {
//            self.stateToggle.toggle()
//        }, label: {
//            Image(uiImage: UIImage(named: "scarletMacaw.png")!)
//                .resizable()
//                .scaledToFit()
//                .frame(maxWidth: 250, maxHeight: 250)
//                .shadow(radius: 10)
//                .rotationEffect(.degrees(imageWiggles ? -5 : 5))
//                .animation(Animation.easeInOut(duration: 3).repeatForever(autoreverses: true))
//                .onAppear() {
//                    imageWiggles.toggle()
//                }
//        }
//        )
//
//    }
//}
//
//// Structs meant to contain a real picture of each specie
//struct RealSamauma: View {
//    var body: some View {
//        ZStack {
//            Image(uiImage: UIImage(named: "realSamauma.png")!)
//                .scaledToFill()
//            VStack {
//                Spacer()
//
//                Text("🌿 This is the Samaúma Tree.")
//                    .font(.system(size: 18, weight: .light, design: .rounded))
//                    .foregroundColor(Color(#colorLiteral(red: 0.2651175260543823, green: 0.2651681900024414, blue: 0.26511088013648987, alpha: 1.0)))
//                    .padding()
//                    .background(
//                        Capsule()
//                            .fill(Color(#colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)))
//                            .shadow(radius: 10)
//                    )
//                    .padding(.bottom, 200)
//            }
//        }
//    }
//}
//
//struct RealJaguar: View {
//    var body: some View {
//        ZStack {
//            Image(uiImage: UIImage(named: "realJaguar.png")!)
//                .scaledToFill()
//            VStack {
//                Spacer()
//
//                Text("🐆 This is the Jaguar.")
//                    .font(.system(size: 18, weight: .light, design: .rounded))
//                    .foregroundColor(Color(#colorLiteral(red: 0.2651175260543823, green: 0.2651681900024414, blue: 0.26511088013648987, alpha: 1.0)))
//                    .padding()
//                    .background(
//                        Capsule()
//                            .fill(Color(#colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)))
//                            .shadow(radius: 10)
//                    )
//                    .padding(.bottom, 200)
//            }
//        }
//    }
//}
//
//struct RealTapir: View {
//    var body: some View {
//        ZStack {
//            Image(uiImage: UIImage(named: "realBrazilianTapir.png")!)
//                .scaledToFill()
//            VStack {
//                Spacer()
//
//                Text("🇧🇷 This is the Brazilian Tapir.")
//                    .font(.system(size: 18, weight: .light, design: .rounded))
//                    .foregroundColor(Color(#colorLiteral(red: 0.2651175260543823, green: 0.2651681900024414, blue: 0.26511088013648987, alpha: 1.0)))
//                    .padding()
//                    .background(
//                        Capsule()
//                            .fill(Color(#colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)))
//                            .shadow(radius: 10)
//                    )
//                    .padding(.bottom, 200)
//            }
//        }
//    }
//}
//
//struct RealSpiderMonkey: View {
//    var body: some View {
//        ZStack {
//            Image(uiImage: UIImage(named: "realSpiderMonkey.png")!)
//                .scaledToFill()
//            VStack {
//                Spacer()
//
//                Text("🐒 This is the Spider Monkey (or Ateles).")
//                    .font(.system(size: 18, weight: .light, design: .rounded))
//                    .foregroundColor(Color(#colorLiteral(red: 0.2651175260543823, green: 0.2651681900024414, blue: 0.26511088013648987, alpha: 1.0)))
//                    .padding()
//                    .background(
//                        Capsule()
//                            .fill(Color(#colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)))
//                            .shadow(radius: 10)
//                    )
//                    .padding(.bottom, 200)
//            }
//        }
//    }
//}
//
//struct RealScarletMacaw: View {
//    var body: some View {
//        ZStack {
//            Image(uiImage: UIImage(named: "realScarletMacaw.png")!)
//                .scaledToFill()
//            VStack {
//                Spacer()
//
//                Text("🦜 This is the Scarlet Macaw.")
//                    .font(.system(size: 18, weight: .light, design: .rounded))
//                    .foregroundColor(Color(#colorLiteral(red: 0.2651175260543823, green: 0.2651681900024414, blue: 0.26511088013648987, alpha: 1.0)))
//                    .padding()
//                    .background(
//                        Capsule()
//                            .fill(Color(#colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)))
//                            .shadow(radius: 10)
//                    )
//                    .padding(.bottom, 200)
//            }
//        }
//    }
//}

// LiveView
import PlaygroundSupport
import SwiftUI
import BookCore
import UIKit

PlaygroundPage.current.liveView = Page3ViewController()
PlaygroundPage.current.needsIndefiniteExecution = true


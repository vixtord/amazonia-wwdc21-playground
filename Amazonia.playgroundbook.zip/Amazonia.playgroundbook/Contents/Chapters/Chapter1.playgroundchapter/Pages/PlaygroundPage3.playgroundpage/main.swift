//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
import PlaygroundSupport

func gatherTheAnimals() {
    if let proxy = PlaygroundPage.current.liveView as? PlaygroundRemoteLiveViewProxy {
        proxy.send(.boolean(true))
    }
}

func scaredAnimals() {
    
}

//#-end-hidden-code
/*:
 ![Gathering the Animals!](page3cover.png)
 
 Oh no, the fires must have scared the animals! Did you know the Amazon Rainforest has around 3 million different species? Indeed! Let's call some of them to show everything is fine now.
 
 * Callout(Remember):
 You can always tap the animals or the tree to see a real picture!
 
 After you've seen them, let's go to the [next page](@next) and dive in the Amazon River to see our aquatic friends too!
 
 */

//#-code-completion(everything, hide)
//#-code-completion(identifier, show, gatherTheAnimals(), scaredAnimals())

// Change to gatherTheAnimals() so we can get in touch with them.

/*#-editable-code*/ scaredAnimals() /*#-end-editable-code*/
